package core_java;

public class CountingWordsInSentence {

    public static void main(String[] args){

    }
}
