package stack_queue;

public class CelebrityProblem {

    public static void main(String[] args){

        int[][] M = {{0, 1, 0},
                {0, 0, 0},
                {0, 1, 0}};

        int n = M.length;

        int ans = -1;
    }
}
