package greedy;

public class B extends A{
    public B(){
        System.out.println("ClassTwo");
    }

}
