package greedy;

import java.util.Stack;

public class A {

    public A(){
        System.out.println("ClassOne");
    }


}
