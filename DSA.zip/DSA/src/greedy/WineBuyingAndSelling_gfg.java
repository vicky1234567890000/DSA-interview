package greedy;

public class WineBuyingAndSelling_gfg {

    public static void main(String[] args){

    }
}
