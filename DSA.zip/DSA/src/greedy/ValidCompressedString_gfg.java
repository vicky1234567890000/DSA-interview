package greedy;

public class ValidCompressedString_gfg {

    public static void main(String[] args){

    }
}
