package greedy;

public class C extends B{
    public C(){
        System.out.println("ClassThree");
    }
}
