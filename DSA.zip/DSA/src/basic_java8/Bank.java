package basic_java8;

@FunctionalInterface
public interface Bank {

    Integer checkBalance(String accNo);
}
