package basic_java8;

public class FisInterview {
    public static void main(String[] args) {

    }
}
