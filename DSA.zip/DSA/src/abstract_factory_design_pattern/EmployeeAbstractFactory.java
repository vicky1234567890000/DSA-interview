package abstract_factory_design_pattern;

public abstract class EmployeeAbstractFactory {

    abstract public Employee getEmployee(String type);
}
