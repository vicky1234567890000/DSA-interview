package observer_design_pattern;

public interface Observer {
    void notified();
}
